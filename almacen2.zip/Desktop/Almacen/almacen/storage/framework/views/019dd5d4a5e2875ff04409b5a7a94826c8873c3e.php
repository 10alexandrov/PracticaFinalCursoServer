<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Mis facturas</title>

    </head>
    <body class="AW-body">
        <div class="main-wrapper">
            <div class ="main-aside">
                <?php echo $__env->make("include.aside-menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
        <div class="main-content">
            <h1> Mis facturas </h1>
            <div class='find_container'>
                <form action="<?php echo e(route('facturas.pedido.find')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="d-flex" style="margin-left: 100px;">
                        <div class="form-group m-20">
                            <label for="p_nombre">Buscar por nunero</label>
                            <input type="text" class="form-control" id="partial" name="partial">
                        </div>
                        <button>Buscar </button>
                    </div>
                </form>
            </div>
            <div class="table_container">
                <table>
                    <tr>
                        <th> Numero </th>
                        <th> Data pedido </th>
                        <th> Suma </th>
                        <th> Mostrar </th>
                        <th> Editar </th>
                        <th> Borrar </th>
                    </tr>
                    <?php $__currentLoopData = $facturas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $factura): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td> <?php echo e($factura->f_id); ?> </td>
                            <td> <?php echo e($factura->f_fecha); ?> </td>
                            <td> <?php echo e($factura->f_suma); ?> </td>
                            <td> <a href='<?php echo e(route('facturas.pedido.show', $factura->f_id)); ?>'>Mostrar </a></td>
                            <td> <a href='<?php echo e(route('facturas.pedido.edit', $factura->f_id)); ?>'>Editar </a></td>
                            <td>
                                <form action="<?php echo e(route('facturas.pedido.destroy', $factura->f_id)); ?>" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button>Borrar </button>
                                </form>
                            </td>
                        </tr>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
            <a  href="<?php echo e(route('factura.pedido.create')); ?>">
                <button class='m-100'>Crear nueva factura </button>
           </a>
        </div>
    </body>
</html>

<style>

    .AW-body {
        display:flex;
    }

    .main-content {
        text-align: center;
        width:100%;
    }

    .table_container {
        display: flex;
        justify-content: center;
        align-items: baseline;
    }

    th, td {
        width: 150px;
        text-align: left;
    }

    td {
        font-weight: 400;
    }

    td a{
        font-weight: 800;
        text-decoration: none;
    }

    .btn-new {
    border-radius: 10px;
    color: white;
    transition: .2s linear;
    background: #0B63F6;
    }

    .btn-new:hover {
        box-shadow: 0 0 0 2px white, 0 0 0 4px #3C82F8;
    }

    .m-100 {
        margin-top: 100px;
    }

    .d-flex {
        display: flex;
    }
</style>
<?php /**PATH /home/alumno/Desktop/Almacen/almacen/resources/views/facturas/pedido.blade.php ENDPATH**/ ?>