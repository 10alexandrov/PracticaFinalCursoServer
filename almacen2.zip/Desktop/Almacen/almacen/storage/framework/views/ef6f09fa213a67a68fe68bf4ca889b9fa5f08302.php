<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

    </head>
    <body class="AW-body">
        <div class="main-wrapper">
            <div class ="main-aside">
                <?php echo $__env->make("include.aside-menu", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            </div>
        </div>
        <div class="main-content">
            <h1> Crear producto nuevo </h1>

            <div class="form">
                <div class="container mt-5">

                    <form action="<?php echo e(route('admin-product-create')); ?>" method="POST" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="name">Product Name</label>
                            <input type="text" class="form-control" id="name" name="name" value="<?php echo e(old('name')); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="width">Width</label>
                            <input type="number" step="0.01" class="form-control" id="width" name="width" value="<?php echo e(old('width')); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="price">Price</label>
                            <input type="number" step="0.01" class="form-control" id="price" name="price" value="<?php echo e(old('price')); ?>" required>
                        </div>

                        <div class="form-group">
                            <label for="image">Product Image</label>
                            <input type="file" class="form-control-file" id="image" name="image" required>
                        </div>

                        <button type="submit" class="btn btn-new">Create Product</button>
                    </form>
                </div>
            </div>
        </div>
    </body>
</html>

<style>

    .AW-body {
        display:flex;
    }

    .main-content {
        text-align: center;
        width:100%;
    }

    .btn-new {
    border-radius: 10px;
    color: white;
    transition: .2s linear;
    background: #0B63F6;
    }

    .btn-new:hover {
        box-shadow: 0 0 0 2px white, 0 0 0 4px #3C82F8;
    }
</style>
<?php /**PATH /home/alumno/Desktop/Almacen/almacen/resources/views/admin-product-new.blade.php ENDPATH**/ ?>